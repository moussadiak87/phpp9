<?php
//Obtenir la date du jour via une fonction
$date = date('d/m/Y');
//Obtenir la date du jour grace à un objet
$today = new DateTime();
?>
<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="UTF-8" />
        <title>Exercice 1</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
        <link rel="stylesheet" href="../assets/style.css" />
    </head>
    <body>
       <?php include('../menu.php'); ?>
       <div class="content">
            <h1>Exercice 1</h1>
            <p>Afficher la date courante en respectant la forme jj/mm/aaaa (ex : 16/05/2016)</p>
            <p><?= $date; ?></p>
            <?php //permet de formater et d'afficher la date  ?>
            <p><?= $today->format('d/m/Y') ?></p>
        </div>
       <div class= "col-1 offset-5">
            <a href="http://phpp9/" alt="Accueil" class="btn btn-danger" >Accueil</a>
        </div>
    </body>
</html>